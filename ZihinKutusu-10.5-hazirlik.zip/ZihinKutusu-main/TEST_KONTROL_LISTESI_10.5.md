# Zihin Kutusu 10.5 — Test Kontrol Listesi

- [ ] GitHub Actions build succeeds
- [ ] AAB release signing succeeds with existing upload key
- [ ] Install and launch on Android device
- [ ] Language selection persists after app restart
- [ ] Check each of the 16 language choices; note any Turkish fallback strings
- [ ] Play through levels 1, 10, 11, 30, 31, 60, 61, 100
- [ ] Test swipe selection horizontally, vertically, diagonally, reverse direction
- [ ] Confirm invalid swipe does not deduct a life/score unexpectedly
- [ ] Test hint, coins, lives, level completion, app restart persistence
- [ ] Race mode: Easy, Normal, Hard; win, lose, retry, return to menu
- [ ] Upload to Open testing and verify on a real device before production

Do not publish until every critical item is verified.
