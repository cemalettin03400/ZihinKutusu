# Zihin Kutusu 5.1

Kelime bulmaca tarzında Android oyun.

## Oyun
- 100 bölüm
- 8x8 harf bulmacası
- Her bölümde 3-4 gizli kelime
- Harflere sırayla dokunarak kelime oluşturma
- Puan, altın ve can sistemi
- İpucu sistemi
- Bölüm ilerlemesi cihazda kaydedilir
- Google test banner reklamı

## GitHub Actions
`.github/workflows/build.yml` dosyası ile GitHub Actions üzerinden APK ve AAB üretilebilir.

APK: `app-debug.apk`
AAB: `app-release.aab`

Reklam kimlikleri şu an Google'ın TEST reklam kimlikleridir. Play Store'a çıkmadan önce kendi AdMob kimliklerin kullanılmalıdır.


- Oyundan çıkış için onaylı ÇIKIŞ düğmesi eklendi.


Türkçe karakterler: Ç, Ğ, İ, I, Ö, Ş, Ü ve ı/i ayrımı korunur. Kelime sayısı bölüm ilerledikçe 4, 5, 6 ve 7 kelimeye çıkar.

## Zihin Kutusu 6.0
- Parmağı kaydırarak komşu ve çapraz harfleri seçme
- Kelimeyi parmak kaldırınca otomatik kontrol etme
- Uzun kelime, seri ve hızlı çözüm puan bonusları
- Türkçe karakter desteği: Ç, Ğ, İ, Ö, Ş, Ü


## Zihin Kutusu 6.0
- Ana menü yenilendi.
- 100 bölümlük bölüm seçme ekranında açılan bölümler gösterilir.
- Bölüm tamamlamaya göre 1, 2 veya 3 yıldız kazanılır.
- Yıldızlar cihazda kaydedilir ve bölüm listesinde görünür.
- Önceki bölümler tekrar oynanabilir; ilerleme kilitlenmez.
- Mevcut Türkçe karakter, kaydırarak kelime seçme, puan, altın, can, ipucu ve çıkış özellikleri korunur.


## Zihin Kutusu 9.0
Başarılar, istatistikler, toplam kelime/bölüm takibi, en uzun seri ve başarı ödülleri eklendi.


## 9.0 Yenilikleri
- Ses ve titreşim geri bildirimleri
- Ayarlar ekranı
- Dokunmatik yanlış seçimlerde can/puan cezası kaldırıldı
- Kaydırma yönü sabitlendi; yanlışlıkla farklı yöne geçişler engellendi
- Doğru/yanlış seçim geri bildirimi


## Google Play hazırlığı
- compileSdk: 36
- targetSdk: 36
- versionName: 10.1
- versionCode: 11
- Bu sürümdeki AdMob kimlikleri hâlâ Google test kimlikleridir; yayın öncesi gerçek AdMob kimlikleri değiştirilmelidir.
- AAB yayınlamak için Google Play App Signing / imzalama adımı ayrıca yapılmalıdır.


## Zihin Kutusu 10.2 – Hata düzeltmeleri ve oynanış
- Harf ızgarası artık ACTION_DOWN / MOVE / UP olaylarını işleyerek gerçek kaydırmalı kelime seçimini destekler.
- Hızlı kaydırmalarda arada kalan hücreler de yakalanır.
- Parmağı kaldırınca seçilen kelime otomatik kontrol edilir.
- İptal edilen dokunma hareketi seçimi temizler.
- Yanlış kelimeyi açıkça kontrol etmek yıldız hesabında hata olarak sayılır; can veya puan cezası uygulanmaz.
- Bölüm tamamlanma ekranındaki altın ödülü doğru gösterilir.


## Sürüm 10.3
- Bilgisayara karşı yarış modu eklendi.
- Yarış öncesi Kolay / Normal / Zor seçimi bulunur.
- Bilgisayarın kelime bulma temposu zorluk seviyesine göre ayarlanır.
- Play Store kısa güncelleme açıklaması: “Bilgisayara karşı yarış! Kolay, Normal veya Zor seviyesini seç; kelimeleri rakibinden önce bul. Kaydırmalı seçim ve oynanış iyileştirmeleri.”
